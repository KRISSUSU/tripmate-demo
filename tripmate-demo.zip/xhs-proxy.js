const http = require('http');
const { execSync } = require('child_process');

const PORT = 19826;

const server = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Content-Type', 'application/json');

  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }

  const url = new URL(req.url, 'http://localhost:' + PORT);
  const query = url.searchParams.get('q') || '旅行攻略';

  console.log('[搜索] ' + query);

  try {
    const cmd = 'npx @jackwener/opencli xiaohongshu search "' + query + '" -n 8 -f json';
    const output = execSync(cmd, { timeout: 15000, encoding: 'utf8' });

    let results = [];
    try {
      results = JSON.parse(output);
    } catch(e) {
      const start = output.indexOf('[');
      const end = output.lastIndexOf(']');
      if (start !== -1 && end !== -1) {
        results = JSON.parse(output.slice(start, end + 1));
      }
    }

    console.log('[结果] 找到 ' + results.length + ' 篇笔记');
    res.writeHead(200);
    res.end(JSON.stringify(results));
  } catch(e) {
    console.error('[错误] ' + e.message);
    res.writeHead(500);
    res.end(JSON.stringify({ error: e.message }));
  }
});

server.listen(PORT, function() {
  console.log('小红书代理已启动：http://localhost:' + PORT);
  console.log('TripMate 页面搜索时会自动调用此代理');
});
